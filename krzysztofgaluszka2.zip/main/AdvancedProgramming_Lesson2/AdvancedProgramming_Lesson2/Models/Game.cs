﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace MvcGame.Models
{
    public class Game
    {
        [Required]
        public int GameId { get; set; }
        [Required]
        public string GameTitle { get; set; }
        [Required]
        public string Platform { get; set; }
        [Required]
        public decimal GamePrice { get; set; }
    }
}
