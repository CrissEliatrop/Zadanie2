# Localization ASP.NET Core Sample

In order to perform clean database setup issue the following commands from 'Package Manager Console':

```
Drop-Database -context MvcContext
Drop-Database -context MvcGameContext
Update-Database -context MvcContext
Update-Database -context MvcGameContext
```

To add new resources modify file SharedResource.resx and corresponding SharedResource files responsible for separate languages.

# Last Updated
2021/04/17
